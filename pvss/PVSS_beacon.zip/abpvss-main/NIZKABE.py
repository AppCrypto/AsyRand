# -*- coding: utf-8 -*-
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, GT, pair
from utils.newsecretutils import SecretUtil
import utils.newjson as newjson
from charm.toolbox.ABEnc import ABEnc, Input, Output
import random
import time, sys
import PVSSABE
import setting
from functools import reduce
ret = {}
keyV = 1
assertExe = True
N = setting.N
t = setting.t

class NIZ():
    def __init__(self, groupObj):
        global util, group
        self.util = SecretUtil(groupObj, verbose=False)
        self.group = groupObj
        self.g, self.h = self.group.random(G1), self.group.random(G1)
        self.sks = {}
        self.pks = {}
        for i in range(0, N):
            name = "AUTH" + str(i)
            self.sks[name] = self.group.random(ZR)
            self.pks[name] = self.g ** self.sks[name]

        self.N = N
        self.t = t

    def createproofs(self, C, policy):
        _s,_w = self.group.random(G1), self.group.random(G1)
        # choose a ploy(x)
        _pi = self.util.calculateSharesDict(self._w, self.util.createPolicy(policy))
        _C0 = (self.h ** _w) * (self.g ** _s)
        _C1 = {}
        for i in range(0, N):
            j = "AUTH" + str(i)
            _C1[j] = self.pks[j] ** _pi[j]
        Cp = {"_C0": _C0, "_C1": _C1}
        self.Cp = Cp
        c = self.group.hash(str(C) + str(Cp), ZR)
        _s1 = _s - c * C['s']
        _w1 = _w - c * C['w']
        _pi1 = {}
        for i in range(0, N):
            j = "AUTH" + str(i)
            _pi1[j] = _pi[j] - c * C['pis'][j]
        NIZK_proofs = {"Cp": Cp, "c": c, "_s1": _s1, "_w1": _w1, "_pi1": _pi1}
        return {"NIZK_proofs": NIZK_proofs}

    def product(numbers):
        # 使用reduce函数计算列表中所有元素的乘积
        return reduce(lambda x, y: x * y, numbers)

    def ver_nizk(self, Com ,proofs):
        if self.Cp["_C0"] != ((self.g ** proofs["_s1"]) * (self.h ** proofs["_w1"])) * (Com["C0"] ** proofs["c"]):
            return False
        # COMPLIE The verify of step 1

        for i in range(1, N):
            j = "AUTH" + str(i)
            if self.Cp["_C1"][j] != (self.pks[j] ** proofs["_pi1"][j]) * Com["C1"][j]:
                return False

        _gs = self.g ** proofs['_s1']
        gs_rec = self.reconstruct(Com,proofs)
        if _gs != gs_rec:
            print("the s in proof is false")
            return False

        return True
# when compile the tree steps of verify, return True

    def reconstruct(self, C ,proofs_rec):
        _uis = []
        _hws = []
        for i in range(1, t):
            for k2 in range(1, N):
                if i != k2:
                    _uis[k2] = k2 / (k2 - i)
            ui = self.product(_uis)
            # get the result of ui
            _hws[i] = self.h ** (ui * proofs_rec['pi1'][i])

        _hw = self.product(_hws)
        gs_rec = self.Cp['_C0'] / ((C['C0'] ** proofs_rec['c']) * _hw)
        return gs_rec


if __name__ == "__main__":
    debug = True
    runtimes = 1
    Nmax = 20
    for n in range(10, Nmax, 10):
        # print("n=",n)
        ret[n] = {"dis": 0, "ver": 0, "rec": 0}
        ts = time.time()
        keyV = n
        for i in range(0, runtimes):
            main()
        # print("("+str(n)+", "+ str('%.2f' % (ret[n]["dis"]*1./runtimes))+") ")
    # print(ret)
    dis = ""
    ver = ""
    rec = ""
    # print the time cost for each phase
    for n in range(10, Nmax, 10):
        dis += "(" + str(n) + ", " + str('%.2fs' % (ret[n]["dis"] * 1. / runtimes)) + ") "
        ver += "(" + str(n) + ", " + str('%.2fs' % (ret[n]["ver"] * 1. / runtimes)) + ") "
        rec += "(" + str(n) + ", " + str('%.2fs' % (ret[n]["rec"] * 1. / runtimes)) + ") "
    # print("")
    # print("distribution time cost:",dis)
    # print("verification time cost:",ver)
    # print("reconstruction time cost:",rec)

# increasing t
# runtimes=4
# n=4

# # for n in range(10, 100, 10):
# for t in range(1,int(n/2), 5):
#     print(t)
#     ts=time.time()
#     ret[t]={"dis":0,"ver":0,"rec":0}
#     keyV=t
#     for i in range(0, runtimes):
#         main(n,t)
#     # print("("+str(n)+", "+ str('%.2f' % (ret[n]["dis"]*1./runtimes))+") ")
# # print(ret)
# rec=""
# for t in range(1, int(n/2), 5):
#     # dis+="("+str(n)+", "+ str('%.2f' % (ret[t]["dis"]*1./runtimes))+") "
#     # ver+="("+str(n)+", "+ str('%.2f' % (ret[t]["ver"]*1./runtimes))+") "
#     rec+="("+str(t)+", "+ str('%.4f' % (ret[t]["rec"]*1./runtimes))+") "
# print(rec)


