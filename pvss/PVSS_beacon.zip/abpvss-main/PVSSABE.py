# realize fig1
# -*- coding: utf-8 -*-
from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, GT, pair
from utils.newsecretutils import SecretUtil
from functools import reduce
import utils.newjson as newjson
from charm.toolbox.ABEnc import ABEnc, Input, Output
import random as mathrandom
import NIZKABE
import time, sys
import setting

ret = {}
keyV = 1
assertExe = True

N = setting.N
t = setting.t


class PVSS_ABE():

    def __init__(self, groupObj):
        global util, group
        self.util = SecretUtil(groupObj, verbose=False)
        # 传输属性
        self.group = groupObj
        self.nizkabe = NIZKABE.NIZ(self.group)

    # PVSS——share
    def pvss_share(self, s=None):
        ts = time.time()
        attrs = ["ATTR%d@AUTH%d" % (j, j) for j in range(0, self.nizkabe.N)]
        part = int(sys.argv[1])
        partAttrNums = int(self.nizkabe.N / part)
        #
        access_policy = '(%d of (' % int(part / 2);
        for i in range(0, part):
            piece = "(%d of (%s))" % (partAttrNums, ", ".join(attrs[i * partAttrNums:partAttrNums * (i + 1)]))
            access_policy += piece + ","
        access_policy = access_policy[:-1] + "))"

        w = self.group.random(ZR)
        Pis = self.util.calculateSharesDict(w, self.util.createPolicy(access_policy))
        self.Pis = Pis
        if s == None:
            s = self.group.random(ZR)

        C0 = (self.nizkabe.h ** w) * (self.nizkabe.g ** s)
        C1 = {}
        for i in range(0, N):
            j = "AUTH" + str(i)
            C1[j] = self.nizkabe.pks[j] ** Pis[j]

        C = {"C0": C0, "C1": C1, "s": s, "w": w, "pis": Pis}
        self.C = C
        # create a NIZK proofs
        proof_sw = self.nizkabe.createproofs(C, access_policy)
        return {'C': C, 'proof_sw': proof_sw}
        # return { 'C0':C0,'C1':C1}

    def pvss_ver(self, C, proofs):
        result_ver = self.nizkabe.ver_nizk(C, proofs)
        if not result_ver:
            print("The proof cost!!!")
            return False
        return result_ver

    # realize PVSS.Pre
    def pvss_PreRecon(self, Cpr, sks_pr):
        # return C1i ** (self.group.hash(GID, ZR)/(ski*  self.group.hash(u, ZR)))
        C1i = {}
        for i in range(1, N):
            j = "AUTH" + str(i)
            C1i[j] = Cpr["C1"][j] ** (1 / sks_pr[j])
        return {'C1i': C1i}

    def product(numbers):
        # 使用reduce函数计算列表中所有元素的乘积
        return reduce(lambda x, y: x * y, numbers)

    def pvss_recon(self, C, cis):
        for i in range(1, N):
            j = "AUTH" + str(i)
            egg1 = pair(cis['C1i'][i], self.nizkabe.pks[i])
            egg2 = pair(self.nizkabe.h, C['C1'][i])
            if egg1 != egg2:
                print("The proof for node i is not satisfied, decryption FAILED")
                exit(0)

        # print(pruned_list)

        # int hw
        uis = []
        hws = []

        for i in range(1, t):
            for k2 in range(1, N):
                if i != k2:
                    uis[k2] = k2 / (k2 - i)
            ui = self.product(uis)
            # get the result of ui
            hws[i] = cis['C1i'][i] ** ui

        hw = self.product(hws)
        gs = C["C0"] / hw
        return gs


def main():
    groupObj = PairingGroup(setting.curveName)
    #  params = {'SS512':a, 'SS1024':a1, 'MNT159':d159, 'MNT201':d201, 'MNT224':d224, 'BN254':f254 }
    # N=n
    # def a pvss role
    abpvss = PVSS_ABE(groupObj)
    print("N=%d,t=%d" % (N, t))
    share_proof = abpvss.pvss_share()
    # print("dis message size:",len(str(trans)))

    ver_result = abpvss.pvss_ver(abpvss.C, share_proof)
    if not ver_result:
        return False

    test_ci = abpvss.pvss_PreRecon(abpvss.C, abpvss.nizkabe.sks)

    test_gs = abpvss.pvss_recon(abpvss.C, test_ci)
    print(test_gs)


if __name__ == "__main__":
    groupObj = PairingGroup(setting.curveName)
    #  params = {'SS512':a, 'SS1024':a1, 'MNT159':d159, 'MNT201':d201, 'MNT224':d224, 'BN254':f254 }
    # N=n
    # def a pvss role
    abpvss = PVSS_ABE(groupObj)
    print("N=%d,t=%d" % (N, t))
    share_proof = abpvss.pvss_share()
    # print("dis message size:",len(str(trans)))

    ver_result = abpvss.pvss_ver(abpvss.C, share_proof)
    if not ver_result:
        print('the ver is false')

    test_ci = abpvss.pvss_PreRecon(abpvss.C, abpvss.nizkabe.sks)
    test_gs = abpvss.pvss_recon(abpvss.C, test_ci)
    print(test_gs)

'''
    groupObj = PairingGroup(setting.curveName)
    #构造制定pair对象
    #  params = {'SS512':a, 'SS1024':a1, 'MNT159':d159, 'MNT201':d201, 'MNT224':d224, 'BN254':f254 }
    # N=n
    print(N)
    cpabe = DCPabe(groupObj)
    #define a Cpabe role
    # attrs = ['ONE', 'TWO', 'THREE', 'FOUR']
    attrs = ["ATTR%d@AUTH%d" % (j,j) for j in range(0, N)]
    # print(attrs)
    # t=int(N/3)
    access_policy = '(%d of (%s))'%(t,", ".join(attrs))
    # (2 of ((2 of (ATTR0@AUTH0,ATTR1@AUTH1,ATTR2@AUTH2)),ATTR3@AUTH3))
    # acp1='(%d of (%s))'%(6,", ".join(attrs[0:10]))
    rand_msg = groupObj.random(GT)
    GID="GID"
    st=time.time()
    ct = cpabe.encrypt(rand_msg, access_policy,GID,cpabe.pks)    
    print("DABE enc:",time.time()-st)
    print("DABE ct size:", len(str(ct))/1024)
    K={"S":[]}

    costtime=0   
    cnt=0
    for i in range(0,N):

        u="ATTR%d@AUTH%d" % (i,i)
        if u in ct["C1"]:
            st=time.time()     
            Ku = cpabe.keygen(GID, ct["C1"][u], u, cpabe.sks["AUTH"+str(i)])
            costtime+=time.time()-st
            cnt+=1
            K[u]=Ku
            K["S"].append(u)
    print("DABE keygen cost",costtime/cnt)



    st=time.time()
    rec_msg = cpabe.decrypt(ct,K,GID)
    print("DABE dec:",time.time()-st)
    assert rand_msg == rec_msg, "FAILED Decryption: message is incorrect"
'''