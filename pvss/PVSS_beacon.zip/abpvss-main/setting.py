N=100
t=int(N/2)+1
curveName="SS512"#
# curveName="MNT159"