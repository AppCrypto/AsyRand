from functools import reduce

def product(numbers):
    # 使用reduce函数计算列表中所有元素的乘积
    return reduce(lambda x, y: x * y, numbers)

# 示例使用
numbers = [2, 3, 4, 5]
result = product(numbers)
print(f"The product of the numbers is: {result}")
