python3 dabe.py
echo "" 
python3 dabe11.py 
echo ""
python3 dabe15.py 